'''
Copyright (C) 2016 Turi
All rights reserved.

This software may be modified and distributed under the terms
of the BSD license. See the LICENSE file for details.
'''

# python egg version
__VERSION__ = '2.1'#{{VERSION_STRING}}
version = '2.1'#{{VERSION_STRING}}
build_number = '347'#{{BUILD_NUMBER}}
