License
=======
See the attached LICENSE.txt file to see the license under which SFrame is distributed.

References
==========
The code for this package is located here: https://github.com/turi-code/SFrame

A lot more documentation regarding the SFrame is available here:
https://turi.com

Contributors
============
Turi Team, https://turi.com
